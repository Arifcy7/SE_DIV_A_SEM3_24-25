package com.example.connectsit.core.theme

import androidx.compose.ui.graphics.Color

val White = Color(0xFFFFFFFF)